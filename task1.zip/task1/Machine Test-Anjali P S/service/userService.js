const User = require("../models/userModel")

const userAdd = async(users) =>{
    User.bulkCreate(users)
}

module.exports = {
    userAdd
}
const XLSX = require('xlsx');
const moment = require('moment');
const userService = require("../service/userService")

const addUsers = async(req,res) =>{
    try{
        const file = req.file;
        if(req?.file?.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){
            return res.status(400).send({errorCode :1002,message : "File should be in xlxs format"})
        }
        const workbook = XLSX.readFile(file.path);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        let data = XLSX.utils.sheet_to_json(worksheet, {
            raw: false, // Ensure dates are not treated as raw values
        });
        const valid = await validateData(data)
        if(!valid.isValid){
           return res.status(400).send({errorCode : 1003 , message : "Uploading failed! Data should be in valid formats",errors: valid.errorRows})
        }
        data = data.map((item) => {
            if (item.hasOwnProperty('id')) {
                delete item.id;
            }
            return item;
        });
        await userService.userAdd(data)
        res.send({message : "Data inserted successfully"})
    }catch(err){
        res.status(500).send(err)
    }
   

}


async function validateData(data){
    const errorRows = [];
    let isValid = true;

    data.forEach((record, index) => {
        let hasError = false;
        const errors = {};

        if (typeof parseInt(record.age) !== 'number') {
            errors.Age = 'Age should be a number';
            hasError = true;
        }

        if (record['dateOfBirth']) {
            const dateFormats = ['M/D/YY', 'M/DD/YY', 'MM/D/YY', 'MM/DD/YY']; // Add more formats if needed
            let validDate = false;
            let parsedDate;
        
            // Try to parse the date using multiple formats
            for (const format of dateFormats) {
                parsedDate = moment(record['dateOfBirth'], format, true);
                if (parsedDate.isValid()) {
                    validDate = true;
                    break;
                }
            }
        
            if (validDate) {
                record['Date of Birth'] = parsedDate.format('YYYY-MM-DD');
            } else {
                errors['Date of Birth'] = 'Date of Birth should be in a valid format (e.g., M/D/YY, M/DD/YY, MM/D/YY, MM/DD/YY)';
                hasError = true;
            }
        }

        if (record.address.length < 25) {
            errors.Address = 'Address should have at least 25 characters';
            hasError = true;
        }

        if (hasError) {
            errorRows.push({ line: index + 2, data: record, errors });
            isValid = false;
        }
    });

    return { isValid, errorRows };
}

module.exports = {
    addUsers
};









module.exports = {
    addUsers
}
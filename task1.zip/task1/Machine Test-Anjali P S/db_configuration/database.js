const { Sequelize } = require("sequelize");
require("dotenv").config();

const DATABASE_NAME = process.env.DATABASE_NAME;
const USER_NAME = process.env.USER_NAME;
const DB_PASSWORD = process.env.DB_PASSWORD;

const sequelize = new Sequelize(DATABASE_NAME, USER_NAME, DB_PASSWORD, {
  host: "localhost",
  dialect: "mysql",
  logging: false,
});

sequelize
  .authenticate()
  .then(() => {
    console.log("db connected");
  })
  .catch((err) => {
    console.log(err);
  });

sequelize.sync({ force: false, alter: "update" })

module.exports = sequelize; 

const express = require('express');
const app = express();
const cors = require('cors')
app.use(cors())
require('dotenv').config();
const PORT = process.env.PORT;

const userRoutes = require("./routes/userRoutes")
app.listen(PORT, (req,res) => {
    console.log("server running");
  });


  app.use((err, req, res, next) => {
    console.log("ggggg");
    if (err.errorCode == 1003) {
        res.status(400).json({ errorCode: 1003, message: 'File format is not supported. Please upload an .xlsx file.' });
    } else {
        // Handle other errors or pass them to the default Express error handler
        next(err);
    }
});
app.use('/users',userRoutes)

const express = require('express');
const multer = require('multer')
const router = express.Router();
const userController = require("../controller/userController")

const fileStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, process.env.FILE_PATH);
    },
    filename: (req, file, cb) => {
      cb(null,file.originalname);
    }
  });


const upload = multer({ storage: fileStorage});

router.post('/',upload.single('file'),(req, res) => {
  if (!req.file) 
    return res.status(400).send({errorCode : 1000 ,message : "File is required"});
  userController.addUsers(req,res)
})

module.exports = router